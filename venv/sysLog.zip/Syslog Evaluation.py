#!/usr/bin/venv python

import re

file = open("sysLog.txt", "r")

regex = re.compile(r'\b\w{9}\b')

words = {}
count = 0
given_words = ['anonymous', 'guest', '1', re.IGNORECASE]
for x in file.read().split():
    count += 1
    if x in given_words:
        words.setdefault(x, 0)
        words[str(x)] += 1
print(count, words)

for line in file:
    nine_letter_words = regex.findall(line)

    for word in nine_letter_words:
        print(word)

file.close()
